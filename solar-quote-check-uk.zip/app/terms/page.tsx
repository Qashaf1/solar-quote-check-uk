import type { Metadata } from "next";
import { LegalPageShell } from "@/components/LegalPageShell";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description: "Terms and conditions for using the Solar Quote Check UK service.",
};

export default function TermsPage() {
  return (
    <LegalPageShell title="Terms &amp; Conditions">
      <p>
        This is placeholder content. Replace it with your organisation&rsquo;s
        full terms of use, explaining that Solar Quote Check UK is a
        lead-generation service that matches homeowners with independent
        installer partners, and that it does not itself supply or install
        solar panels.
      </p>
      <p>
        Sections to include: description of the service, eligibility, user
        responsibilities, installer relationships, limitation of liability,
        and governing law.
      </p>
    </LegalPageShell>
  );
}
