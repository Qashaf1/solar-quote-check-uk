import type { Metadata } from "next";
import { LegalPageShell } from "@/components/LegalPageShell";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How Solar Quote Check UK collects, uses and protects your data.",
};

export default function PrivacyPolicyPage() {
  return (
    <LegalPageShell title="Privacy Policy">
      <p>
        This is placeholder content. Replace it with your organisation&rsquo;s
        full privacy policy, covering what data is collected through the
        eligibility checker, how it is shared with installer partners, how
        long it is retained, and how users can request access to or deletion
        of their data in line with UK GDPR.
      </p>
      <p>
        Sections to include: data we collect, how we use your data, sharing
        with third-party installers, data retention, your rights, and how to
        contact us about privacy matters.
      </p>
    </LegalPageShell>
  );
}
