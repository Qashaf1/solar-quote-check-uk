import type { Metadata } from "next";
import { Mail, Phone } from "lucide-react";
import { LegalPageShell } from "@/components/LegalPageShell";

export const metadata: Metadata = {
  title: "Contact Us",
  description: "Get in touch with the Solar Quote Check UK team.",
};

export default function ContactPage() {
  return (
    <LegalPageShell title="Contact Us">
      <p>
        Have a question about your eligibility check or an existing quote?
        Get in touch and we&rsquo;ll point you in the right direction.
      </p>
      <div className="not-prose mt-6 flex flex-col gap-3 text-ink dark:text-white">
        <a href="mailto:hello@solarquotecheck.co.uk" className="flex items-center gap-2 hover:text-primary">
          <Mail className="h-4 w-4" /> hello@solarquotecheck.co.uk
        </a>
        <a href="tel:+441234567890" className="flex items-center gap-2 hover:text-primary">
          <Phone className="h-4 w-4" /> 01234 567 890
        </a>
      </div>
    </LegalPageShell>
  );
}
