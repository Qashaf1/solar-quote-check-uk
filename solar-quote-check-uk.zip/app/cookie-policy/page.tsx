import type { Metadata } from "next";
import { LegalPageShell } from "@/components/LegalPageShell";

export const metadata: Metadata = {
  title: "Cookie Policy",
  description: "How Solar Quote Check UK uses cookies and similar technologies.",
};

export default function CookiePolicyPage() {
  return (
    <LegalPageShell title="Cookie Policy">
      <p>
        This is placeholder content. Replace it with details of the cookies
        used on this site, for example essential cookies required for the
        eligibility checker to function, and any analytics cookies used to
        understand site performance.
      </p>
      <p>
        Sections to include: what cookies are, the categories used on this
        site, how to manage cookie preferences, and how to contact us with
        questions.
      </p>
    </LegalPageShell>
  );
}
