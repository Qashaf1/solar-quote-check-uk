import type { ReactNode } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export function LegalPageShell({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <>
      <Header />
      <main className="mx-auto max-w-3xl px-5 py-16 sm:py-24">
        <h1 className="font-display text-3xl font-bold tracking-tight text-ink dark:text-white sm:text-4xl">
          {title}
        </h1>
        <div className="prose prose-sm sm:prose-base mt-8 max-w-none text-ink-soft dark:text-white/70">
          {children}
        </div>
      </main>
      <Footer />
    </>
  );
}
